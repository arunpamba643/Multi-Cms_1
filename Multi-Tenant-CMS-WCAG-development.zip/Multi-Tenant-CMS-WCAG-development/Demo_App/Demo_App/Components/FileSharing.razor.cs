﻿using Microsoft.AspNetCore.Components;

namespace Demo_App.Components
{
    public partial class FileSharing : ComponentBase
    {
    }

}
