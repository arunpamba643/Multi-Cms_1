using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Demo_App.Pages
{
    public class EditBlogPostModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
