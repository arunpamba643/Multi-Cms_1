namespace Demo_App.Data;

public enum ComponentType
{
    ContactPerson,
    EventDetail,
    BlogDetail,
    FreeText,
    BlankSpace,
    Image,
    HTMLEditor,
    EventList,
    BlogList, Sponsors,
    Honoree,
    Honorees,
    ImageGallery,
    FileShare
}