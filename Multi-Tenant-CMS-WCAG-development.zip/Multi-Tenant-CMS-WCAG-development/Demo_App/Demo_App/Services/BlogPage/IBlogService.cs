﻿namespace Demo_App.Services.BlogPage
{
    public interface IBlogService
    {
    }
}
