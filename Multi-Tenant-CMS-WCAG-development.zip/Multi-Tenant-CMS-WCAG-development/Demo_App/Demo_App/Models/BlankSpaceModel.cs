﻿namespace Demo_App.Models
{
    public class BlankSpaceModel
    {
        public string Height { get; set; } = "150px";
        public string Width { get; set; } = "100%";
    }
}
