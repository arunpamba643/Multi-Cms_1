namespace ScratchCode;

public enum ComponentType
{
    ContactPerson,
    EventList,
    BlogList
}