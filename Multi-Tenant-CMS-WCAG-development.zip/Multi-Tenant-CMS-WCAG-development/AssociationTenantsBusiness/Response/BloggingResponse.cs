﻿namespace AssociationBusiness.Response
{
    public class BloggingResponse
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
