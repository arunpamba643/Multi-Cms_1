
namespace ScratchCode.ApiModels
{
    public class Image
    {
        public string Url { get; set; }

        
        public string Name { get; set; }

        
        public string Id { get; set; }
    }
}