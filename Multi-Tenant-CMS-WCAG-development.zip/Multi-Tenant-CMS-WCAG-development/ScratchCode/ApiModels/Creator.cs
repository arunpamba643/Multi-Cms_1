﻿namespace ScratchCode.ApiModels
{
    public class Creator
    {
        
        public string Id { get; set; }

        
        public string Name { get; set; }

        public string Label { get; set; }

        public string AvatarImageUrl { get; set; }
    }
}