
# Start creating a new Page by selecting a template
![img_1.png](img_1.png)

# Empty page to start selected
### Create a "database"  would be 'add a new row of containers'
Then a popup should come up to select the type of row you want to use. The Rows are predifined with a set 
of components and can't be changed but selected.
In each container of a row you can again select a component to add to the container.
![img.png](img.png "Empty State")

# Colors
### You can use any tailwind color based on this scheme
We currently went with some of the dark orange/brown colors at highlight and stone/neutral as background
https://tailwindcss.com/docs/customizing-colors
![img_2.png](img_2.png)
### This is a Screenshot of the current Me App
![img_3.png](img_3.png)


# JSON
### I added all the Json file and renamed it to the current data in our system
Please be aware, that the data is not complete as some references are missing. This is not important to you, you can just work with the data you can use.
# Important, some design decisions werent the best!
## This is why we want to rework the whole CMS design. Therefore many ideas like TemplateId weren't the best. 