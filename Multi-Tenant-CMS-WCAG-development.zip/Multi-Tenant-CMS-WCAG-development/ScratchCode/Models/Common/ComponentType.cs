namespace ScratchCode.Models;

public enum ComponentType
{
    SingleContactPerson,
    EventList,
    BlogList,
    ListContactPerson
}
