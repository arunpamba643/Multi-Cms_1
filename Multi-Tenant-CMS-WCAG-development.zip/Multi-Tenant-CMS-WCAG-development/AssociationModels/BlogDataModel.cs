﻿namespace AssociationModels
{
    internal class BlogDataModel
    {
    }
}
