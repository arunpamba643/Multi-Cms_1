﻿using AssociationEntities.Models;
using Microsoft.AspNetCore.Http;
 
using System;
using System.Collections.Generic;
using System.IO.Compression;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.AccessControl;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace AssociationEntities.Common
{
    public class FileManagerUtilities
    {

    }
}
