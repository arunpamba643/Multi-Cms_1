﻿using System;
using System.Collections.Generic;

namespace AssociationEntities.Models;

public partial class Sampledatum
{
    public int SdId { get; set; }

    public string? Data { get; set; }

    public string? SampleData { get; set; }
}
