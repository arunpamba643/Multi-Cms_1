﻿namespace WebsiteDemo.Models
{
    public class ImageData
    {
        public int Id { get; set; }
        public string ImageUrl { get; set; }
    }
}
