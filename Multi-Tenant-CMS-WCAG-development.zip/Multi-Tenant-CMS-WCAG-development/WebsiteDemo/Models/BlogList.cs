﻿namespace WebsiteDemo.Models
{
    public class BlogList
    {
        public int BlogId { get; set; }
        public string BlogName { get; set; }
        public string BlogDescription { get; set; }
        public string BlogImage { get; set; }
        public string ScopeType { get; set; }
    }
}
