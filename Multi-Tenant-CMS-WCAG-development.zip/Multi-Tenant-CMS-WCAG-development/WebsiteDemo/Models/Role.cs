﻿namespace WebsiteDemo.Models
{
    public class Role
    {
        public string RoleName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
